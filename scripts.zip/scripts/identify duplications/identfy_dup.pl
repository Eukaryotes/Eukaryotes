﻿#!perl -w
use strict;

my $format = $ARGV[0];	# suffix of tree files e.g. "tre"
my $species_list = $ARGV[1];	# a file containing all species name, one per line
my $output = $ARGV[2];	# name of the output file

my %species;
open IN, "< $species_list" or die "Can't open species_list!";
while (<IN>) {
	chomp;
	$species{$_} = 1;
}
close (IN);

my @out;

foreach my $file (glob "*.$format") {
	
	my $ori_tree;
	open IN, "< $file" or die "Can't open $file!";
	while (<IN>) {
		chomp;
		$ori_tree .= $_;
	}
	close (IN);
	
	$ori_tree =~ s/:[\d\.]+//g;
	$ori_tree =~ s/\)[\d\.]+/\)/g;
	$ori_tree =~ s/;//;
	
	my @tree = &number_tree($ori_tree);
	my @leaf = &leaf($tree[0]);
	my @dup_gene;
	
	foreach my $species (keys %species) {
		my $frequency = grep { /^$species/ } @leaf;
		if ($frequency > 1) {
			my $indicator = 1;
LEVEL1:	foreach my $level (2..$tree[1]) {
				my @bipartition = split /#$level#/, $tree[0];
				my @part = ($bipartition[0].",".$bipartition[2], $bipartition[1]);
LEVEL2:	foreach my $part (@part) {
					my @part_leaf = &leaf($part);
					my $part_freq = grep { /^$species/ } @part_leaf;
					next if ($part_freq < $frequency);
					foreach my $part_leaf (@part_leaf) {
						unless ($part_leaf =~ /^$species/) {
							next LEVEL2;
						}
					}
					$indicator = 0;
					last LEVEL1;
				}
			}
			if ($indicator) {
				push @dup_gene, $species;	
			}
		}
	}
	
	if (defined($dup_gene[0])) {
		my $dup_gene = join "\t", @dup_gene;
		push @out, "$file\t$dup_gene\n";
	}
		
}

open OUT, "> $output" or die "Can't open OUT!";
print OUT @out;
close (OUT);

exit;

sub number_tree {
	my $tree = $_[0];
	my $max;
	while ($tree =~ /\(/) {
		$max++;
		$tree =~ s/\(/#$max#/;
	}
	foreach my $node (reverse 1..$max) {
		$tree =~ s/(#$node#.*?)\)/$1#$node#/;	
	}
	return ($tree, $max);
}

sub leaf {
	my $tree = $_[0];
	$tree =~ s/#\d+#/,/g;
	my @tree = split /,/, $tree;
	my @leaf;
	foreach my $leaf (@tree) {
		if ($leaf =~ /\w/) {
			push @leaf, $leaf;
		}	
	}
	return @leaf;
}