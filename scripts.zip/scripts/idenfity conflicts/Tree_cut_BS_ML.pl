#!perl -w

use strict;

my $format = $ARGV[0];	# suffix of tree files e.g. "tre"
my $bs_cutoff = $ARGV[1];	# bootstrap cutoff e.g. "80"; all results will be written to the folder "./BS_$bs_cutoff", which should be created first

foreach my $file (glob "*.$format") {
	next unless (-e "$file");
	open IN, "< $file" or die "Can't open IN: $file!\n";
	my @nexus_tree = <IN>;
	close (IN);
	my $nexus_tree = join "", @nexus_tree;
	$nexus_tree =~ s/\n//g;
	$nexus_tree =~ s/\);/\)100:0.0;/;
	@nexus_tree = split //, $nexus_tree;
	$nexus_tree = join "", @nexus_tree;
	my $number_of_brackets = grep { /\(/ } @nexus_tree;
	for my $location (1..$number_of_brackets) {
		$nexus_tree =~ s/\(/#$location#/;
	}
	$nexus_tree =~ s/\):/\)100:/;
	for (my $location = $number_of_brackets; $location >= 1; $location--) {
		$nexus_tree =~ /#$location#.*?\)(\d+):/;
		my $indicator = $1 - $bs_cutoff;
		if ($indicator >= -0.5) {
			$nexus_tree =~ s/#$location#(.*?)\)/#$location#$1#$location#/;
		} else {
			$nexus_tree =~ s/#$location#(.*?)\)\d+:\d+\.\d+/$1/;
		}
	}
	
	foreach my $location (1..$number_of_brackets) {
		if ($nexus_tree =~ /#$location#/) {
			$nexus_tree =~ s/#$location#(.*?)#$location#/\($1\)/;
		}
	}
	$nexus_tree =~ s/\)100:0.0;/\);/;
	open OUT, "> .\\BS_"."$bs_cutoff\\$file.tre" or die "Can't open OUT!\n";
	print OUT $nexus_tree;
	close (OUT);
}

exit;