#!perl -w
use strict;

my $format = $ARGV[0];	# suffix of tree files e.g "tre"
my $guide_tree_file = $ARGV[1];	# reference species tree
my $output = $ARGV[2];	# name of the output file
my $out_tree_file = $ARGV[3];	# generate an annotated guide tree showing the name of each node

my $guide_tree;
open IN, "< $guide_tree_file" or die "Can't open guide tree!";
while (<IN>) {
	chomp;
	$guide_tree .= $_;
}
close (IN);

$guide_tree =~ s/;//;

my @guide_tree = &number_tree($guide_tree);
my @guide_tree_leaf = &leaf($guide_tree[0]);

open OUT, "> $out_tree_file" or die "Can't open $out_tree_file";
print OUT &out_tree(@guide_tree);
close (OUT);

my %guide_tree;
foreach my $guide_tree_bipartition (2..$guide_tree[1]) {
	my @guide_subtree = split /#$guide_tree_bipartition#/, $guide_tree[0];
	my @guide_subtree_leaf = sort(&leaf($guide_subtree[1]));
	my $guide_subtree_leaf = join "\t", @guide_subtree_leaf;
	$guide_tree{$guide_subtree_leaf} = $guide_tree_bipartition - 1;
}
my %reverse_guide_tree = reverse %guide_tree;

my %agree; my %disagree; my %relevant;

foreach my $file (glob "*.$format") {
	
	my $tree;
	open IN, "< $file" or die "Can't open $file!";
	while (<IN>) {
		chomp;
		$tree .= $_;
	}
	close (IN);
	
	$tree =~ s/:[\d\.]+//g;
	$tree =~ s/\)[\d\.]+/\)/g;
	$tree =~ s/;//;
	
	my @tree = &number_tree($tree);
	my @leaf = &leaf($tree[0]);
	my %leaf;
	foreach my $leaf (@leaf) {
		$leaf{$leaf} = 1;
	}
	
	my %guide_tree_plus;
	if ($#leaf == $#guide_tree_leaf) {
		%guide_tree_plus = %guide_tree;
	}	else	{
		my @reverse_guide_tree = sort {$a <=> $b} keys %reverse_guide_tree;
		foreach my $reverse_guide_tree (@reverse_guide_tree) {
			my $current_bipartition = $reverse_guide_tree{$reverse_guide_tree};
			foreach my $species (@guide_tree_leaf) {
				next if (defined($leaf{$species}));
				$current_bipartition =~ s/$species\t?//;
			}
			$current_bipartition =~ s/\t$//;
			next unless ($current_bipartition =~ /\t/);
			
			$guide_tree_plus{$current_bipartition} = $reverse_guide_tree;
		}	
	}
	
	foreach my $node (%guide_tree_plus) {
		$relevant{$node}++;	
	}
	
	foreach my $tree_bipartition (2..$tree[1]) {
		my @subtree = split /#$tree_bipartition#/, $tree[0];
		if (defined($subtree[2])) {
			$subtree[0] .= pop @subtree;
		}
		foreach my $subtree (@subtree) {
			my @subtree_leaf = sort(&leaf($subtree));
			my $subtree_leaf = join "\t", @subtree_leaf;
			if (defined($guide_tree_plus{$subtree_leaf})) {
				$agree{$guide_tree_plus{$subtree_leaf}}++;
				last;
			}
		}
		foreach my $node (keys %guide_tree_plus) {
			unless (&agree($node, @subtree)) {
				${$disagree{$guide_tree_plus{$node}}}{$file} = 1;
			}
		}
	}
		
}

open OUT, "> $output" or die "Can't open OUT!";
foreach my $node (1..($guide_tree[1]-1)) {
	print OUT "$node\t";
	if (defined($relevant{$node})) {
		print OUT "$relevant{$node}\t";	
	} else	{
		print OUT "0\t";
	}
	if (defined($agree{$node})) {
		print OUT "$agree{$node}\t";	
	} else	{
		print OUT "0\t";
	}
	if (defined($disagree{$node})) {
		print OUT (scalar keys %{$disagree{$node}})."\n";	
	} else	{
		print OUT "0\n";
	}
}
close (OUT);

exit;

sub out_tree {
	my @tree = @_;
	foreach my $node (1..$tree[1]) {
		my $node_name = $node - 1;
		$tree[0] =~ s/#$node#(.*)#$node#/\($1\)$node_name/;
	}
	return "$tree[0];";
}

sub number_tree {
	my $tree = $_[0];
	my $max;
	while ($tree =~ /\(/) {
		$max++;
		$tree =~ s/\(/#$max#/;
	}
	foreach my $node (reverse 1..$max) {
		$tree =~ s/(#$node#.*?)\)/$1#$node#/;	
	}
	return ($tree, $max);
}

sub leaf {
	my $tree = $_[0];
	$tree =~ s/#\d+#/,/g;
	my @tree = split /,/, $tree;
	my @leaf;
	foreach my $leaf (@tree) {
		if ($leaf =~ /\w/) {
			push @leaf, $leaf;
		}	
	}
	return @leaf;
}

sub agree {
	my $guide_tree = shift @_;
	my @user_tree = @_;
	my @guide_tree = split /\t/, $guide_tree;
	my %guide_tree;
	foreach my $leaf (@guide_tree) {
		$guide_tree{$leaf} = 1;
	}
	my $disagree = 0;
	foreach my $user_tree (@user_tree) {
		my $overlap = 0;
		my @leaf = &leaf($user_tree);
		foreach my $leaf (@leaf) {
			if (defined($guide_tree{$leaf})) {
				$overlap++;	
			}
		}
		unless ($overlap == 0 || $overlap == scalar @leaf) {
			$disagree++;
		}
	}
	if ($disagree == 2) {
		return 0;
	}	else	{
		return 1;
	}
}